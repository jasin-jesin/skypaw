"""
SkyPaw - Behaviour Controller 
Author: Muralitharan Apikheshinie
Purpose: Master state machine. Decides which behaviour runs each cycle
         based on sensor inputs from every other module.

Priority (highest first):
    1. PREDATOR   - fast-approaching object
    2. OBSTACLE   - close static object
    3. PHOTOTAXIS - dark environment
    4. WANDER     - default walk forward

Public API:
    tick()  -> one decision cycle
    run()   -> infinite loop
"""

import time

import gait
import obstacle
import predator
import phototaxis

# =========================
# STATE CONSTANTS
# =========================
STATE_WANDER     = "WANDER"
STATE_OBSTACLE   = "OBSTACLE"
STATE_PREDATOR   = "PREDATOR"
STATE_PHOTOTAXIS = "PHOTOTAXIS"
STATE_STUCK      = "STUCK"

# =========================
# TIMING
# =========================
LOOP_DELAY          = 0.05
PHOTOTAXIS_INTERVAL = 2.0
_last_light_check   = 0.0


# =========================
# ONE DECISION CYCLE
# =========================
def tick():
    """Run ONE cycle of the state machine. Returns chosen state."""
    global _last_light_check

    # --- PRIORITY 1: PREDATOR (reflex) ---
    if predator.check_predator():
        print("[BEHAVIOUR] -> PREDATOR")
        predator.predator_response()
        return STATE_PREDATOR

    # --- PRIORITY 2: OBSTACLE ---
    front_left  = obstacle.get_distance_avg(obstacle.LEFT,  samples=2)
    front_right = obstacle.get_distance_avg(obstacle.RIGHT, samples=2)
    left_block  = (0 < front_left  < obstacle.OBSTACLE_THRESHOLD)
    right_block = (0 < front_right < obstacle.OBSTACLE_THRESHOLD)
    if left_block or right_block:
        print("[BEHAVIOUR] -> OBSTACLE (L:", front_left, "R:", front_right, ")")
        result = obstacle.avoid_obstacle()
        if result != 0:
            print("[BEHAVIOUR] Avoidance failed, STUCK.")
            gait.sit()
            return STATE_STUCK
        return STATE_OBSTACLE

    # --- PRIORITY 3: PHOTOTAXIS (rate limited) ---
    now = time.monotonic()
    if (now - _last_light_check) >= PHOTOTAXIS_INTERVAL:
        _last_light_check = now
        if phototaxis.is_dark():
            print("[BEHAVIOUR] -> PHOTOTAXIS")
            phototaxis.seek_light()
            return STATE_PHOTOTAXIS

    # --- PRIORITY 4: WANDER ---
    print("[BEHAVIOUR] -> WANDER")
    interrupted = gait.walk()
    if interrupted:
        print("[BEHAVIOUR] Walk interrupted by predator hook.")
        predator.predator_response()
        return STATE_PREDATOR
    return STATE_WANDER


# =========================
# MAIN LOOP
# =========================
def run():
    print("[BEHAVIOUR] SkyPaw starting up...")

    # Register predator as motion interrupt - lets walks abort mid-cycle
    gait.set_interrupt_check(predator.check_predator)

    gait.sit()
    time.sleep(1.5)
    gait.stand()
    predator.wings_close()
    time.sleep(1)

    print("[BEHAVIOUR] Entering main loop.")
    try:
        while True:
            state = tick()
            if state == STATE_STUCK:
                print("[BEHAVIOUR] Robot is stuck. Halting.")
                break
            time.sleep(LOOP_DELAY)

    except KeyboardInterrupt:
        print("[BEHAVIOUR] Interrupted by user.")
    finally:
        predator.wings_close()
        gait.stand()
        time.sleep(1)
        gait.pca.deinit()
        print("[BEHAVIOUR] Shutdown complete.")


if __name__ == "__main__":
    run()